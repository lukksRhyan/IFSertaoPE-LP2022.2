nome = input("Insira seu nome: ")
for pedaco in range(len(nome)):
    print(nome[pedaco:])