import random

palavras = ["computador", "transporte", "celular", "cachorro", "edificio", "filha", "academia", "entretenimento"]

numeroSorteado = random.randrange(0,len(palavras))
sorteada = palavras[numeroSorteado]

saida = list(sorteada)

print("Qual palavra é essa?\n")
random.shuffle(saida)
print("    ".join(saida))
acertou = False 
for i in range(3):
    entrada = input()
    if entrada == sorteada:
        acertou = True
        break
    else:
        entrada = input("Errou, tente novamente. ")

if acertou:
    print("Parabéns, você acertou!")
else:
    print(f"Você perdeu...\n{sorteada} era a palavra correta.")
